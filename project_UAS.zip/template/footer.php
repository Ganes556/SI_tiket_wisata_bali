</body>
<script src="./assets/js/bootstrap.bundle.min.js"></script>
<script src="./assets/js/script.js"></script>
<?php if(isset($anotherScript)): ?>
    <script src="./assets/js/<?=$anotherScript?>"></script>
<?php endif; ?>
</html>